import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class Collage extends StatelessWidget {
  final List imageList;
  final String placeholderImage;
  const Collage({
    Key? key,
    required this.imageList,
    required this.placeholderImage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(7.0),
      ),
      clipBehavior: Clip.antiAlias,
      child: SizedBox(
        height: 50,
        width: 50,
        child: Stack(
          children: [
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: imageList.length < 3 ? 1 : 2,
              children: [
                for (int _ in [1, 2, 3, 4])
                  Image(
                    image: AssetImage(placeholderImage),
                  ),
              ],
            ),
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: imageList.length < 3 ? 1 : 2,
              children: imageList
                  .map(
                    (image) => CachedNetworkImage(
                      fit: BoxFit.cover,
                      errorWidget: (context, _, __) => Image(
                        fit: BoxFit.cover,
                        image: AssetImage(placeholderImage),
                      ),
                      imageUrl: image['image']
                          .toString()
                          .replaceAll('http:', 'https:'),
                      placeholder: (context, _) => Image(
                        fit: BoxFit.cover,
                        image: AssetImage(placeholderImage),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class OfflineCollage extends StatelessWidget {
  final List imageList;
  final String placeholderImage;
  const OfflineCollage({
    Key? key,
    required this.imageList,
    required this.placeholderImage,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(7.0),
      ),
      clipBehavior: Clip.antiAlias,
      child: SizedBox(
        height: 50,
        width: 50,
        child: Stack(
          children: [
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: imageList.length < 3 ? 1 : 2,
              children: [
                for (int _ in [1, 2, 3, 4])
                  Image(
                    image: AssetImage(placeholderImage),
                  ),
              ],
            ),
            GridView.count(
              shrinkWrap: true,
              crossAxisCount: imageList.length < 3 ? 1 : 2,
              children: imageList.map((image) {
                return image == null
                    ? const Image(
                        image: AssetImage('assets/album.png'),
                      )
                    : Image(
                        image: FileImage(
                          File(
                            image['image'].toString(),
                          ),
                        ),
                      );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
